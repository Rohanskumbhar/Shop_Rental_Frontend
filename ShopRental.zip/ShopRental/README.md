# Shop Rental - Multi-Page Website

A modern, responsive multi-page website for shop rental services built with HTML, CSS, and JavaScript.

## 🏗️ Website Structure

### Pages
- **`index.html`** - Entry point with automatic redirect to Home.html
- **`Home.html`** - Main homepage with hero section, features, and shop listings
- **`about.html`** - About us page with company information
- **`services.html`** - Services offered by Shop Rental
- **`shops.html`** - Dedicated page for browsing all available shops
- **`contact.html`** - Contact form and company contact information

## 🎨 Features

### Design & UI
- **Modern Design**: Clean, professional interface with consistent branding
- **Responsive Layout**: Mobile-first design that works on all devices
- **Dark Mode Support**: Automatic dark mode detection and styling
- **Smooth Animations**: Hover effects and smooth transitions throughout

### Navigation
- **Sticky Header**: Navigation bar that stays at the top while scrolling
- **Mobile Menu**: Hamburger menu for mobile devices
- **Active Page Highlighting**: Current page is highlighted in navigation
- **Consistent Branding**: Logo and navigation structure across all pages

### Functionality
- **Shop Listings**: Display available shops with detailed information
- **Add Shop Form**: Modal form for property owners to list new shops
- **Contact Forms**: Working contact forms on multiple pages
- **Interactive Elements**: Expandable shop information and smooth scrolling

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Local web server (optional, for development)

### Installation
1. Download or clone the project files
2. Open `index.html` in your web browser
3. The website will automatically redirect to `Home.html`

### Development
- All files are self-contained with embedded CSS and JavaScript
- No external dependencies required
- Easy to customize colors, fonts, and styling using CSS variables

## 🎯 Key Features by Page

### Home.html
- Hero section with call-to-action
- Feature highlights
- Shop listings with add shop functionality
- Contact section
- Footer with site information

### About.html
- Company overview and mission
- Why choose us section
- Professional presentation

### Services.html
- Comprehensive service list
- Clear service descriptions
- Professional layout

### Shops.html
- Dedicated shop browsing page
- Expandable shop information
- Google Maps integration links

### Contact.html
- Contact form
- Company contact details
- Professional presentation

## 🎨 Customization

### Colors
The website uses CSS custom properties for easy color customization:
```css
:root {
    --bg: #f4f6fb;           /* Background color */
    --text: #1f2a37;         /* Text color */
    --brand: #2d3e50;        /* Brand color */
    --accent: #ffd700;       /* Accent color */
    --surface: rgba(255,255,255,0.7); /* Surface color */
}
```

### Fonts
- Primary: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif
- Easily customizable in CSS

## 📱 Responsive Design

- **Mobile First**: Designed for mobile devices first
- **Breakpoints**: Responsive design with mobile and desktop considerations
- **Touch Friendly**: Optimized for touch devices
- **Performance**: Fast loading and smooth interactions

## 🔧 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📁 File Structure


## 🚀 Deployment

### Local Development
1. Open any HTML file in your browser
2. Use a local server for best development experience

### Web Hosting
1. Upload all files to your web hosting provider
2. Ensure `index.html` is set as the default page
3. Test all navigation links

## 🤝 Contributing

This is a static website template that can be easily customized:
- Modify colors and styling in CSS variables
- Add new pages following the existing structure
- Customize content for your business needs
- Add additional functionality as needed

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 📞 Support

For questions or support:
- Email: support@shoprental.com
- Phone: +1 234-567-8901

---

**Shop Rental** - Connecting businesses with perfect spaces since 2025.
